# CHANGELOG.md

## [1.3.1] - 2023-02-13

- Update dependencies

## [1.3.0] - 2022-07-15

- Update dependencies
- Update React to v18
- Replace Sass with CSS files

## [1.1.0] - 2022-01-27

- Replace CRA (Create React App) with Vite
- Remove Craco
- Update dependencies

## [1.0.1] - 2020-10-19

Fix issue with testimonail image on mobile

## [1.0.0] - 2020-10-15

First release
